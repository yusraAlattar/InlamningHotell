package com.company;

public class Square {

    private int height;
    private int width;
    private int area;

    public Square(int h, int w) {
        height = h;
        width = w;
        area = w * h;
    }

    public int getArea() {//gör att area som är privat kan nås från andra classer
        return area;
    }

    public void setHeight(int h) {
        height = h;
        area = height * width;//varje gång setHeight används ska area beräkning göras om
        //get o set används för att ändra private egenskaperna på våra egna villkor.
    }

    public void say() {
        System.out.println("w: " + width + ", h: " + height);
    }
}
