package com.company;

import java.io.File;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainMeny {

    ArrayList<Person> persons = new ArrayList<>();


    Scanner myScan = new Scanner(System.in);

    public MainMeny() {
        persons = (ArrayList<Person>)FileUtility.loadObject("person.ser");
    }

    public void printHeader() {
        System.out.println("----------------------------------------");
        System.out.println("|             WELCOME TO                 |");
        System.out.println("|         ** Hotel Heavenly **           |");
        System.out.println("----------------------------------------");
    }

    public void printMenu() {
        System.out.println("Please make a selection:\n" +
                "1. Book a room\n" +
                "2. Remove my booking\n" +
                "3. Show my personal booking\n" +
                "4. For our employeers only: Show all bookings and customers\n" +
                "5. Help\n" +
                "6. Exit ");
    }

    public int getFirstChoice() {
        int userChoice = myScan.nextInt();

        switch (userChoice) {
            case 1:
                makeBooking();
                break;
            case 2:
                System.out.println("please enter your name to remove your booking");

                Services.removeName(persons);//metoden körs i classen services eftersom persons finns endast här


                break;

            case 3:
                findName();


                break;

            case 4:
                System.out.println("Name of guest" + "     " + "phone number of guest" + "   " + "room type");
                for (Person person : persons) {
                    System.out.println(person.name + "     " + person.phone + "    " + person.roomChoice);
                }


                //Services.readAllLines();
                System.out.println("..........................................................................");
                break;
        }

        return userChoice;//returnerar valet av aanvändaren, t.ex 6
    }

    private void findName() {
        Scanner myScan = new Scanner(System.in);
        System.out.println("Write a name to find in textfile");
        String name = myScan.nextLine();
        for(Person p: persons){
            if(p.name.equals(name)) {
                System.out.println(p.name + p.phone + p.roomChoice);
            }
        }


        //ArrayList<String> namesFromFile = (ArrayList<String>)FileUtility.loadText("dada.txt");
        // int indexOfName = namesFromFile.indexOf(name);
        // System.out.println("Found: " + namesFromFile.get(indexOfName));
    }

    private void makeBooking() {
        System.out.println("What kind of room do you wish to book,\n" +
                "please make one of those coming selections:\n" +
                "1. Single Room\n" +
                "2. Doublie Room\n" +
                "3. Suit");

        Scanner myScan = new Scanner(System.in);
        int roomChoice = myScan.nextInt();
        Room room = null;//Ala Room är ngn sorts Room
        switch (roomChoice) {
            case 1:
                room = new SingleRoom();
                break;
            case 2:
                room = new DoubleRoom();
                break;
            case 3:
                room = new Suit();
                break;
        }

        room.printRoomAdvantages();//körs för alla 3 casen

        myScan.nextLine();//rensar enter

        System.out.println("please enter your name: ");
        String name = myScan.nextLine();
        System.out.println("please enter your phone number: ");
        String number = myScan.nextLine();
        Person perspnObj = new Person(name, number, roomChoice);
        persons.add(perspnObj);

    }

    public void save() {
        FileUtility.saveObject("person.ser", persons);
    }

}