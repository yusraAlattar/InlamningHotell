package com.company;

import java.io.Serializable;

public class Person implements Serializable {
    public String name;
    public String phone;
    public int roomChoice;

    public Person(String name, String phone, int roomChoice) {
        this.name = name;
        this.phone = phone;
        this.roomChoice = roomChoice;
    }

}
