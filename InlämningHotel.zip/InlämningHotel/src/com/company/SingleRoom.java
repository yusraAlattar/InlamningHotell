package com.company;

public class SingleRoom extends Room {

    public SingleRoom() {
        roomPrice = 100;
        info = " single room ";
        roomAdvantages = new roomOptions[]{

                roomOptions.TV,
                roomOptions.Internet,
                roomOptions.Aircondition,
                roomOptions.SharedBathroom


        };
    }
}