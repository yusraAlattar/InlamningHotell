package com.company;

public class Suit extends Room {

    public Suit() {
        roomPrice = 200;
        info = " suit ";
        roomAdvantages = new roomOptions[] {
                roomOptions.TV,
                roomOptions.Internet,
                roomOptions.Bathroom,
                roomOptions.Jacuzzi,
                roomOptions.Breakfast,
                roomOptions.KingSizeBed,
                roomOptions.Minibar,
                roomOptions.Computer,
                roomOptions.Aircondition
        };//hämtar från enumet roomOptions

    }
}