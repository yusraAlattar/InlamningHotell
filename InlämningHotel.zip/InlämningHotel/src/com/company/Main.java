package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {



    public static void main(String[] args) {


        MainMeny mainMeny = new MainMeny();
        mainMeny.printHeader();

        int mainMenuChoice = 0;
        while (mainMenuChoice != 6) {
            mainMeny.printMenu();
            mainMenuChoice = mainMeny.getFirstChoice();//get från return-svaret från funktionen getFirstChoice
        }
        mainMeny.save();
    }
}
