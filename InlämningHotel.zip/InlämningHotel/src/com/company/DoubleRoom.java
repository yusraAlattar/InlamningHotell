package com.company;

public class DoubleRoom extends Room {

    public DoubleRoom() {
        roomPrice = 150;
        info = " double room ";
        roomAdvantages = new roomOptions[]{
                roomOptions.TV,
                roomOptions.Internet,
                roomOptions.TwoBeds,
                roomOptions.Bathroom,
                roomOptions.Aircondition,


        };
    }
}
                //roomAdvantages = new String[]{"TV", "INTERNET", "Bathroom", "breakfast", "two beds", "Minibar"};


