package com.company;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Services {
    public static void readAllLines() {

        String fileName = "dada.txt";

        try {

            List<String> lines = Files.readAllLines(Paths.get(fileName));

            for (String line : lines) {

                System.out.println(line);

            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    //Write some lines to a file
    public static void writeAllLines(String name, String phoneNumber, int roomChoice) {
        List<String> lines = new ArrayList<>();
        try {
            lines = Files.readAllLines(Paths.get("dada.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        lines.add(name + "            " + phoneNumber + "                               " + roomChoice);

        try {
            Files.write(Paths.get("dada.txt"), lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Services.readAllLines();


        //FileUtility.loadObject("dada.txt");
        //System.out.println("Person from file: " + myObj);

    }

    public static void removeName(List<Person> personsToRemoveFrom) {//tar emot listan, namnet på listan behöver inte vara samma som den som skickar från mainmeny()

        Scanner myScan = new Scanner(System.in);
        String name1 = myScan.nextLine();

        // ArrayList<String> namesFromFile = (ArrayList<String>) FileUtility.loadText("dada.txt");

        // assert namesFromFile != null;
        // int indexOfName = personsToRemoveFrom.indexOf(name1);//jämför ett namn
        /*for(int i =0; i<personsToRemoveFrom.size();i++) {
            if (personsToRemoveFrom.get(i).name.equals(name1)) {//jämföra ett namn inuti ett object
                personsToRemoveFrom.remove(i);
                break;
            }
        }
*/
        for (Person p : personsToRemoveFrom) {
            if (p.name.equals(name1)) {
                personsToRemoveFrom.remove(p);//Vi skickar in objektet p
                break;
            }
        }

        /* for (Person p : personsToRemoveFrom) {
            System.out.println(p.name);
        } */

        //System.out.println("Found: " + personsToRemoveFrom.remove(indexOfName));

    }
}
