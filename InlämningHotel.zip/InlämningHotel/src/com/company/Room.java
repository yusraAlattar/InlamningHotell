package com.company;

public class Room {
    protected int roomPrice;

    protected String info;

    enum roomOptions {
        TV,
        Aircondition,
        Internet,
        Bathroom,
        TwoBeds,
        Breakfast,
        Minibar,
        Computer,
        Jacuzzi,
        SharedBathroom,
       KingSizeBed

    }

    public roomOptions[] roomAdvantages;




    public void printRoomAdvantages() {
        System.out.println("     advantages" + info + "\n");
        for (roomOptions i : roomAdvantages) {
            System.out.println(i);
        }
        System.out.println("Price :" + roomPrice + "$" + " for the day");
    }
}
